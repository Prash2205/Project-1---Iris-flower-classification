import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Iris - Iris.csv')

# Display the first few rows of the dataset
print(df.head())

# Display data types and null values
print(df.info())

# Display basic statistics
print(df.describe())

# Check for missing values
print(df.isnull().sum())

# Handle missing values (e.g., by dropping or imputing)
df = df.dropna()  # Example: drop rows with missing values

# Histograms
df.hist(figsize=(10, 8))
plt.show()

# Count plots for categorical variables
sns.countplot(x='Species', data=df)
plt.show()

# Correlation matrix
corr_matrix = df.corr()
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm')
plt.show()

# Pairplot for selected variables
sns.boxplot(x='PetalLengthCm', y= 'PetalWidthCm', data=df)
plt.show()

sns.boxplot(x='SepalLengthCm', y= 'SepalWidthCm', data=df)
plt.show()

# Boxplot for outlier detection
sns.boxplot(x='PetalLengthCm', data=df)
plt.show()

sns.boxplot(x='PetalWidthCm', data=df)
plt.show()

sns.boxplot(x='SepalLengthCm', data=df)
plt.show()

sns.boxplot(x='SepalWidthCm', data=df)
plt.show()

# Class distribution
sns.countplot(x='Species', data=df)
plt.show()

# Summary statistics
print(df.groupby('Species').agg({'PetalLengthCm': ['mean', 'std', 'min', 'max']}))
print(df.groupby('Species').agg({'PetalWidthCm': ['mean', 'std', 'min', 'max']}))
print(df.groupby('Species').agg({'SepalLengthCm': ['mean', 'std', 'min', 'max']}))
print(df.groupby('Species').agg({'SepalWidthCm': ['mean', 'std', 'min', 'max']}))
