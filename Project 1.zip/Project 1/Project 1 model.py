import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score, classification_report
from sklearn import tree

#Load and explore the dataset
flow = pd.read_csv('Iris - Iris.csv')
print(flow)

#Prepare features and target variables
#Where X is features and Y is target variable
X = flow.drop(columns=['Id','Species'])
print(X)
Y = flow['Species']
print(Y)

#Split the dataset into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

#Build and train the decision tree model
model1 = DecisionTreeClassifier()
model1.fit(X_train, Y_train)

#Make predictions on the test set
predictions = model1.predict(X_test)

#Export decision tree visualisation
model = DecisionTreeClassifier()
model.fit(X, Y)
tree.export_graphviz(model, out_file='Flower-predictor.dot',feature_names= ['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm'],class_names= sorted(Y.unique()), label= 'all', rounded= True, filled= True)

#Evaluate the model - Accuracy
score = accuracy_score(Y_test, predictions)
print("Model accuracy:")
print(score)

# Evaluate the model - Precision
precision = precision_score(Y_test, predictions, average=None)
print("Precision for each class:")
print(precision)

# Classification Report
class_report = classification_report(Y_test, predictions)
print("Classification Report:")
print(class_report)